
// exit trax0r
var o_O