#!/bin/bash

./autogen-clean.sh
./autogen.sh

echo "ac_cv_func_malloc_0_nonnull=yes" > arm-linux.autogen
export CC=$CC_MINI"gcc"
export CXX=$CC_MINI"g++"
export CONFIG_SITE=arm-linux.autogen
./configure --build=i386-linux --host=arm-linux --target=arm  --enable-static --enable-shared --prefix=$PWD/build
