./configure -embedded arm -xplatform qws/linux-arm-g++ -prefix /usr/local/mini2440/qt-4.8.5/build -qt-mouse-tslib -little-endian
