#!/bin/sh

# Give path to kernel source to which patch to be updated as a command line argument, while executing patch.
if [ -z $1 ] ;									

then 
	echo "Usage error: Parse the kernel-source path" 		
else

	cp Kconfig 		$1/arch/arm/mach-s3c24xx/Kconfig		&&
	echo "update: arch/arm/mach-s3c24xx/Kconfig"				;
	cp mach-mini2440.c 	$1/arch/arm/mach-s3c24xx/mach-mini2440.c 	&&
	echo "update: arch/arm/mach-s3c24xx/mach-mini2440.c"			;
	cp s3c2410_ts.c 	$1/drivers/input/touchscreen/s3c2410_ts.c 	&&
	echo "update: drivers/input/touchscreen/s3c2410_ts.c"

fi;
