
supervivi-128M supports 128M / 256M / 512M / 1GB NAND Flash.

Version: supervivi-1026
